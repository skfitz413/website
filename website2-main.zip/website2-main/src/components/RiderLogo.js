import React from 'react'

export function RiderLogo(props) {
  return (
<svg {...props} width="108" height="108" version="1.1" viewBox="0 0 108 108" xmlns="http://www.w3.org/2000/svg">
        <linearGradient id="a" x1="94.33" x2="20.33" y1="59.37" y2="16.91" gradientTransform="translate(1.4969 1.6198)" gradientUnits="userSpaceOnUse">
        <stop stopColor="#dd1265" offset="0"/>
        <stop stopColor="#dd1265" offset=".48"/>
        <stop stopColor="#fdb60d" offset=".94"/>
        </linearGradient>
    <linearGradient id="b" x1="50.33" x2="79.66" y1="12.76" y2="93.76" gradientTransform="translate(1.4969 1.6198)" gradientUnits="userSpaceOnUse">
        <stop stopColor="#087cfa" offset=".14"/>
        <stop stopColor="#dd1265" offset=".48"/>
        <stop stopColor="#087cfa" offset=".96"/>
    </linearGradient>
    <linearGradient id="c" x1="28.36" x2="50.02" y1="15.26" y2="92.26" gradientTransform="translate(1.4969 1.6198)" gradientUnits="userSpaceOnUse">
        <stop stopColor="#dd1265" offset=".28"/>
        <stop stopColor="#fdb60d" offset=".97"/>
    </linearGradient>
    <g transform="translate(111.95 5.1309)" fill="#fff" stroke="#fff" strokeLinecap="round" strokeLinejoin="round" strokeWidth="12">
        <path d="m-9.9467 38.219-67.3-37.35 45.06 66.95 9.26-6.07z"/>
        <path d="m-36.797 22.989-8.43-20.61-18.65 18.36 7.63 66.62 18.07 9.51 28.23-16.49z"/>
        <path d="m-77.247 0.86888-28.7 19.33 10.67 65.93 27.52 10.58 35.57-28.89z"/>
    </g>
    <path d="m102 43.35-67.3-37.35 45.06 66.95 9.26-6.07z" fill="url(#a)"/>
    <path d="m75.147 28.12-8.43-20.61-18.65 18.36 7.63 66.62 18.07 9.51 28.23-16.49z" fill="url(#b)"/>
    <path d="m34.697 5.9998-28.7 19.33 10.67 65.93 27.52 10.58 35.57-28.89z" fill="url(#c)"/>
    <path d="m23.997 24.12h60v60h-60z"/>
    <g transform="translate(1.4969 1.6198)" fill="#fff">
        <path d="m29.98 71.16h22.5v3.75h-22.5z"/>
        <path d="m30 29.92h10.3a9 9 0 0 1 6.57 2.29 7.08 7.08 0 0 1 1.94 5.16v0.06a7 7 0 0 1-4.84 7l5.52 8.06h-5.81l-4.83-7.22h-3.85v7.22h-5zm10 11c2.42 0 3.81-1.29 3.81-3.19v-0.06c0-2.13-1.48-3.23-3.9-3.23h-4.91v6.48z"/>
        <path d="m52.93 29.92h8.8c7.09 0 12 4.87 12 11.22v0.07c0 6.35-4.9 11.28-12 11.28h-8.8zm5 4.48v13.6h3.84a6.43 6.43 0 0 0 6.8-6.74v-0.06a6.49 6.49 0 0 0-6.8-6.81z"/>
    </g>
</svg>
)
}
