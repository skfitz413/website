import React from 'react'

export function MSBuildLogo(props) {
    return (
        <img src="/msbuild.png" alt="MSBuild" {...props} />
    )
}
